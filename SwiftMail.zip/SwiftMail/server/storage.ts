import { emails, users, type User, type InsertUser, type Email, type InsertEmail } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Email operations
  createEmail(email: InsertEmail): Promise<Email>;
  getEmailById(id: number): Promise<Email | undefined>;
  getEmailsByUser(userId: number): Promise<Email[]>;
  getEmailsForFolder(userId: number, folder: string): Promise<Email[]>;
  markEmailAsRead(id: number): Promise<Email | undefined>;
  markEmailAsStarred(id: number, starred: boolean): Promise<Email | undefined>;
  moveEmailToFolder(id: number, folder: string): Promise<Email | undefined>;
  deleteEmail(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private emails: Map<number, Email>;
  private userIdCounter: number;
  private emailIdCounter: number;

  constructor() {
    this.users = new Map();
    this.emails = new Map();
    this.userIdCounter = 1;
    this.emailIdCounter = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Email operations
  async createEmail(insertEmail: InsertEmail): Promise<Email> {
    const id = this.emailIdCounter++;
    const now = new Date();
    const email: Email = { 
      ...insertEmail, 
      id, 
      read: false, 
      starred: false, 
      deleted: false, 
      createdAt: now,
      folder: 'inbox'
    };
    this.emails.set(id, email);
    return email;
  }

  async getEmailById(id: number): Promise<Email | undefined> {
    return this.emails.get(id);
  }

  async getEmailsByUser(userId: number): Promise<Email[]> {
    return Array.from(this.emails.values()).filter(
      (email) => email.toUserId === userId && !email.deleted
    );
  }

  async getEmailsForFolder(userId: number, folder: string): Promise<Email[]> {
    if (folder === 'sent') {
      return Array.from(this.emails.values()).filter(
        (email) => email.fromUserId === userId && !email.deleted
      );
    }
    
    return Array.from(this.emails.values()).filter(
      (email) => email.toUserId === userId && email.folder === folder && !email.deleted
    );
  }

  async markEmailAsRead(id: number): Promise<Email | undefined> {
    const email = this.emails.get(id);
    if (!email) return undefined;
    
    const updatedEmail = { ...email, read: true };
    this.emails.set(id, updatedEmail);
    return updatedEmail;
  }

  async markEmailAsStarred(id: number, starred: boolean): Promise<Email | undefined> {
    const email = this.emails.get(id);
    if (!email) return undefined;
    
    const updatedEmail = { ...email, starred };
    this.emails.set(id, updatedEmail);
    return updatedEmail;
  }

  async moveEmailToFolder(id: number, folder: string): Promise<Email | undefined> {
    const email = this.emails.get(id);
    if (!email) return undefined;
    
    const updatedEmail = { ...email, folder };
    this.emails.set(id, updatedEmail);
    return updatedEmail;
  }

  async deleteEmail(id: number): Promise<boolean> {
    const email = this.emails.get(id);
    if (!email) return false;
    
    const updatedEmail = { ...email, deleted: true };
    this.emails.set(id, updatedEmail);
    return true;
  }
}

export const storage = new MemStorage();
