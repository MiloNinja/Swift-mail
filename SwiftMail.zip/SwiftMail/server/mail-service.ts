import nodemailer from 'nodemailer';
import { log } from './vite';

interface EmailData {
  from: string;
  to: string;
  subject: string;
  text: string;
  html?: string;
}

class MailService {
  private transporter: nodemailer.Transporter;
  private initialized: boolean = false;
  
  constructor() {
    // We'll initialize the transporter once we have SMTP credentials
    this.transporter = null as any;
  }
  
  async init(config?: {
    host: string;
    port: number;
    secure: boolean;
    auth: {
      user: string;
      pass: string;
    }
  }) {
    try {
      if (config) {
        // Use provided config if available
        this.transporter = nodemailer.createTransport(config);
      } else if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
        // Use environment variables if available
        this.transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: parseInt(process.env.SMTP_PORT || '587'),
          secure: process.env.SMTP_SECURE === 'true',
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
          }
        });
      } else {
        // Use a test account from Ethereal Email
        const testAccount = await nodemailer.createTestAccount();
        log('Created test email account:', 'mail');
        log(`- User: ${testAccount.user}`, 'mail');
        log(`- Pass: ${testAccount.pass}`, 'mail');
        
        this.transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          secure: false,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass
          }
        });
      }
      
      this.initialized = true;
      log('Mail service initialized successfully', 'mail');
      return true;
    } catch (error) {
      log(`Failed to initialize mail service: ${error}`, 'mail');
      return false;
    }
  }
  
  async sendEmail(emailData: EmailData): Promise<boolean> {
    if (!this.initialized) {
      const initialized = await this.init();
      if (!initialized) {
        log('Could not initialize mail service before sending', 'mail');
        return false;
      }
    }
    
    try {
      const info = await this.transporter.sendMail(emailData);
      
      log(`Email sent: ${info.messageId}`, 'mail');
      // If using Ethereal, log the preview URL
      if (info.messageId && info.messageId.includes('ethereal')) {
        log(`Preview URL: ${nodemailer.getTestMessageUrl(info)}`, 'mail');
      }
      
      return true;
    } catch (error) {
      log(`Error sending email: ${error}`, 'mail');
      return false;
    }
  }
  
  // Helper method to send an email from a Swift user to any recipient
  async sendFromSwiftUser(
    fromEmail: string,
    toEmail: string,
    subject: string,
    body: string
  ): Promise<boolean> {
    // Format the email with Swift branding
    const htmlBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(to right, #5b21b6, #2563eb, #10b981); padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">Swift Mail</h1>
        </div>
        <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none;">
          <p>${body.replace(/\n/g, '<br>')}</p>
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;">
          <p style="color: #6b7280; font-size: 12px;">
            This email was sent from ${fromEmail} via Swift Mail
          </p>
        </div>
      </div>
    `;
    
    return this.sendEmail({
      from: `"Swift Mail" <${fromEmail}>`,
      to: toEmail,
      subject,
      text: body,
      html: htmlBody
    });
  }
}

// Create a singleton instance of the mail service
export const mailService = new MailService();