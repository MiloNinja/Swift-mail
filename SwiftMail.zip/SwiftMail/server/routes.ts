import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEmailSchema, insertUserSchema, loginSchema } from "@shared/schema";
import { ZodError } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";
import { mailService } from "./mail-service";

// Extend Express Session
declare module 'express-session' {
  interface Session {
    userId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session
  const SessionStore = MemoryStore(session);
  app.use(
    session({
      secret: "swift-email-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false, maxAge: 86400000 }, // 1 day
      store: new SessionStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
    })
  );

  // Authentication middleware
  const authenticate = (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Ensure username doesn't contain spaces and email is valid
      if (userData.username.includes(" ")) {
        return res.status(400).json({ message: "Username cannot contain spaces" });
      }
      
      // Check if username is taken
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      // Create Swift email address
      userData.email = `${userData.username}@swift.com`;
      
      // Check if email is taken
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already taken" });
      }
      
      const user = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Set user session
      req.session.userId = user.id;
      
      res.status(201).json({ user: userWithoutPassword });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Set user session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      res.json({ user: userWithoutPassword });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", authenticate, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId as number);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  // Email routes
  app.post("/api/emails", authenticate, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      
      // Validate email data
      const { toEmail, subject, body } = req.body;
      
      if (!toEmail || !subject || !body) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Get sender information
      const sender = await storage.getUser(userId);
      if (!sender) {
        return res.status(404).json({ message: "Sender not found" });
      }
      
      // Check if this is an internal Swift email or external
      const isInternalEmail = toEmail.endsWith('@swift.com');
      
      if (isInternalEmail) {
        // For internal emails, store in our database
        const recipient = await storage.getUserByEmail(toEmail);
        if (!recipient) {
          return res.status(404).json({ message: "Swift recipient not found" });
        }
        
        const emailData = {
          fromUserId: userId,
          toUserId: recipient.id,
          subject,
          body
        };
        
        const email = await storage.createEmail(emailData);
        res.status(201).json({ email, sent: true });
      } else {
        // For external emails, use the mail service to send via SMTP
        const success = await mailService.sendFromSwiftUser(
          sender.email,
          toEmail,
          subject,
          body
        );
        
        if (!success) {
          return res.status(500).json({ message: "Failed to send external email" });
        }
        
        // Also store a copy in the sent folder
        const emailData = {
          fromUserId: userId,
          toUserId: userId, // Store it with the sender as recipient for record-keeping
          subject,
          body,
          folder: 'sent',
          externalRecipient: toEmail // Add a field to mark that this went to an external recipient
        };
        
        const email = await storage.createEmail(emailData);
        res.status(201).json({ email, sent: true, external: true });
      }
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.get("/api/emails/folder/:folder", authenticate, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const { folder } = req.params;
      
      if (!["inbox", "sent", "starred", "trash"].includes(folder)) {
        return res.status(400).json({ message: "Invalid folder" });
      }
      
      let emails;
      if (folder === "starred") {
        // For starred, get all non-deleted emails where starred is true
        emails = (await storage.getEmailsByUser(userId)).filter(email => email.starred);
      } else if (folder === "trash") {
        // For trash, get all deleted emails
        emails = Array.from((await storage.getEmailsByUser(userId))).filter(email => email.deleted);
      } else {
        // For other folders (inbox, sent)
        emails = await storage.getEmailsForFolder(userId, folder);
      }
      
      res.json({ emails });
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.get("/api/emails/:id", authenticate, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const { id } = req.params;
      
      const email = await storage.getEmailById(parseInt(id));
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      // Users can only access emails they sent or received
      if (email.fromUserId !== userId && email.toUserId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // If user is recipient and email is unread, mark as read
      if (email.toUserId === userId && !email.read) {
        await storage.markEmailAsRead(email.id);
      }
      
      res.json({ email });
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.patch("/api/emails/:id/star", authenticate, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const { id } = req.params;
      const { starred } = req.body;
      
      if (typeof starred !== "boolean") {
        return res.status(400).json({ message: "Starred must be a boolean" });
      }
      
      const email = await storage.getEmailById(parseInt(id));
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      // Users can only star emails they received
      if (email.toUserId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedEmail = await storage.markEmailAsStarred(parseInt(id), starred);
      
      res.json({ email: updatedEmail });
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.patch("/api/emails/:id/folder", authenticate, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const { id } = req.params;
      const { folder } = req.body;
      
      if (!folder || !["inbox", "trash"].includes(folder)) {
        return res.status(400).json({ message: "Invalid folder" });
      }
      
      const email = await storage.getEmailById(parseInt(id));
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      // Users can only move emails they received
      if (email.toUserId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedEmail = await storage.moveEmailToFolder(parseInt(id), folder);
      
      res.json({ email: updatedEmail });
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  app.delete("/api/emails/:id", authenticate, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const { id } = req.params;
      
      const email = await storage.getEmailById(parseInt(id));
      
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      // Users can only delete emails they received
      if (email.toUserId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      await storage.deleteEmail(parseInt(id));
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  // User search endpoint for compose email
  app.get("/api/users/search", authenticate, async (req, res) => {
    try {
      const searchTerm = req.query.q as string;
      
      if (!searchTerm || searchTerm.length < 2) {
        return res.json({ users: [] });
      }
      
      // Get all users and filter by search term
      const allUsers = Array.from(await Promise.all(
        Array.from({ length: 100 }).map(async (_, i) => await storage.getUser(i + 1))
      )).filter(Boolean) as any[];
      
      const filteredUsers = allUsers.filter(user => 
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      // Return only necessary fields
      const users = filteredUsers.map(({ id, username, email, firstName, lastName }) => ({
        id, username, email, firstName, lastName
      }));
      
      res.json({ users });
    } catch (error) {
      res.status(500).json({ message: "Something went wrong" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
