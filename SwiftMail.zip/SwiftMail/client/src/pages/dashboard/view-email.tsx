import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import DashboardLayout from "@/layouts/dashboard-layout";
import EmailViewer from "@/components/email/email-viewer";
import { Email, User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, AlertCircle } from "lucide-react";

interface ViewEmailProps {
  id: number;
}

export default function ViewEmail({ id }: ViewEmailProps) {
  const [location, navigate] = useLocation();

  // Get current user
  const { data: userData } = useQuery<{ user: User }>({
    queryKey: ["/api/auth/me"],
  });

  // Get email by ID
  const { 
    data: emailData, 
    isLoading, 
    isError 
  } = useQuery<{ email: Email }>({
    queryKey: [`/api/emails/${id}`],
  });

  // Get user data for sender
  const { data: usersData } = useQuery<{ users: User[] }>({
    queryKey: ["/api/users/search", ""],
    enabled: !!emailData?.email,
  });

  const getSender = () => {
    if (!usersData?.users || !emailData?.email) return undefined;
    const senderId = emailData.email.fromUserId;
    return usersData.users.find(user => user.id === senderId);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="email-content flex-1 overflow-auto bg-white flex items-center justify-center">
          <div className="text-center p-8">
            <Loader2 className="h-12 w-12 text-purple-600 animate-spin mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">Loading email</h3>
            <p className="text-gray-500">Please wait while we retrieve the email content.</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (isError || !emailData?.email) {
    return (
      <DashboardLayout>
        <div className="email-content flex-1 overflow-auto bg-white flex items-center justify-center">
          <div className="text-center p-8">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">Email not found</h3>
            <p className="text-gray-500 mb-4">
              The email you're looking for doesn't exist or you don't have permission to view it.
            </p>
            <Button onClick={() => navigate("/inbox")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Inbox
            </Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="email-content flex-1 overflow-auto bg-white">
        <EmailViewer 
          email={emailData.email} 
          sender={getSender()} 
          currentUser={userData?.user}
        />
      </div>
    </DashboardLayout>
  );
}
