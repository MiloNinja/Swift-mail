import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/dashboard-layout";
import EmailListItem from "@/components/email/email-list-item";
import { Email, User } from "@shared/schema";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { 
  RefreshCw, 
  MoreVertical,
  Loader2,
  InboxIcon,
  MailX
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface InboxProps {
  folder?: string;
}

export default function Inbox({ folder = "inbox" }: InboxProps) {
  const [selectedEmails, setSelectedEmails] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);
  const { toast } = useToast();

  // Get user data
  const { data: userData } = useQuery<{ user: User }>({
    queryKey: ["/api/auth/me"],
  });

  // Get emails for folder
  const { 
    data: emailsData, 
    isLoading, 
    isError, 
    refetch 
  } = useQuery<{ emails: Email[] }>({
    queryKey: [`/api/emails/folder/${folder}`],
  });

  // Get user data for senders
  const { data: usersData } = useQuery<{ users: User[] }>({
    queryKey: ["/api/users/search", ""],
    enabled: !!emailsData,
  });

  useEffect(() => {
    // Reset selection when folder changes
    setSelectedEmails(new Set());
    setSelectAll(false);
  }, [folder]);

  const handleSelectAll = (checked: boolean) => {
    setSelectAll(checked);
    
    if (checked && emailsData?.emails) {
      setSelectedEmails(new Set(emailsData.emails.map(email => email.id)));
    } else {
      setSelectedEmails(new Set());
    }
  };

  const handleSelectEmail = (emailId: number, selected: boolean) => {
    const newSelected = new Set(selectedEmails);
    
    if (selected) {
      newSelected.add(emailId);
    } else {
      newSelected.delete(emailId);
    }
    
    setSelectedEmails(newSelected);
  };

  const handleRefresh = () => {
    refetch();
    toast({
      title: "Refreshed",
      description: "Your emails have been refreshed.",
    });
  };

  const getSenderForEmail = (email: Email) => {
    if (!usersData?.users) return undefined;
    
    // For sent folder, we display the recipient
    const userId = folder === "sent" ? email.toUserId : email.fromUserId;
    return usersData.users.find(user => user.id === userId);
  };

  const getDisplayTitle = () => {
    switch (folder) {
      case "inbox": return "Inbox";
      case "sent": return "Sent Mail";
      case "starred": return "Starred";
      case "trash": return "Trash";
      default: return "Emails";
    }
  };

  return (
    <DashboardLayout title={getDisplayTitle()}>
      <div className="email-list flex-1 overflow-auto bg-white border-r border-gray-200">
        {/* Email list header */}
        <div className="border-b border-gray-200 bg-white sticky top-0 z-10">
          <div className="flex items-center justify-between px-4 py-2">
            <div className="flex items-center">
              <Checkbox
                className="h-4 w-4 text-purple-600 focus:ring-purple-600 border-gray-300 rounded"
                checked={selectAll}
                onCheckedChange={handleSelectAll}
              />
              <span className="ml-2 text-sm text-gray-600">Select all</span>
            </div>
            <div className="flex space-x-2">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleRefresh}
                disabled={isLoading}
              >
                {isLoading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <RefreshCw className="h-5 w-5 text-gray-500" />
                )}
              </Button>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-5 w-5 text-gray-500" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Email list content */}
        <div className="divide-y divide-gray-200">
          {isLoading ? (
            <div className="py-20 flex flex-col items-center justify-center text-gray-500">
              <Loader2 className="h-10 w-10 animate-spin mb-4" />
              <p>Loading emails...</p>
            </div>
          ) : isError ? (
            <div className="py-20 flex flex-col items-center justify-center text-gray-500">
              <MailX className="h-10 w-10 mb-4" />
              <p>Failed to load emails</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => refetch()}
              >
                Try Again
              </Button>
            </div>
          ) : emailsData?.emails && emailsData.emails.length > 0 ? (
            emailsData.emails.map((email) => (
              <EmailListItem
                key={email.id}
                email={email}
                sender={getSenderForEmail(email)}
                isActive={selectedEmails.has(email.id)}
                onSelect={(selected) => handleSelectEmail(email.id, selected)}
              />
            ))
          ) : (
            <div className="py-20 flex flex-col items-center justify-center text-gray-500">
              <InboxIcon className="h-10 w-10 mb-4" />
              <p>No emails in {getDisplayTitle().toLowerCase()}</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Empty state for email content on wider screens */}
      <div className="email-content flex-1 overflow-auto bg-white hidden md:flex items-center justify-center">
        <div className="text-center p-8">
          <InboxIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">Select an email to read</h3>
          <p className="text-gray-500 max-w-md">
            Choose an email from the list to view its contents here.
          </p>
        </div>
      </div>
    </DashboardLayout>
  );
}
