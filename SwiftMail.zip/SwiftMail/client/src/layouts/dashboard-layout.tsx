import { useCallback, useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import EmailSidebar from "@/components/email/email-sidebar";
import ComposeModal from "@/components/email/compose-modal";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { PenSquare, Search, Menu, Inbox } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useIsMobile } from "@/hooks/use-mobile";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function DashboardLayout({ children, title = "Inbox" }: DashboardLayoutProps) {
  const [composeOpen, setComposeOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [contentOpen, setContentOpen] = useState(false);
  const isMobile = useIsMobile();
  const [location, navigate] = useLocation();

  // Get current user
  const { data: userData } = useQuery<{ user: User }>({
    queryKey: ["/api/auth/me"],
  });

  const logout = useCallback(async () => {
    await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "include"
    });
    navigate("/login");
  }, [navigate]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
    setContentOpen(false);
  };

  const toggleMobileContent = () => {
    setContentOpen(!contentOpen);
    setSidebarOpen(false);
  };

  const onCompose = () => {
    setComposeOpen(true);
    setSidebarOpen(false);
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          {/* Logo and Title */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <span className="text-purple-600 font-bold text-2xl">Swift</span>
                <span className="text-blue-500 font-normal text-2xl">Mail</span>
              </Link>
            </div>
            
            {/* Mobile navigation controls */}
            {isMobile && (
              <div className="md:hidden flex space-x-4">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={toggleSidebar}
                  className="text-gray-500 hover:text-purple-600"
                >
                  <Menu className="h-6 w-6" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={toggleMobileContent}
                  className="text-gray-500 hover:text-purple-600"
                >
                  <Inbox className="h-6 w-6" />
                </Button>
              </div>
            )}
          </div>
          
          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-xl mx-4">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <Input 
                className="pl-10" 
                placeholder="Search emails" 
                type="search"
              />
            </div>
          </div>
          
          {/* User Profile */}
          <div className="flex items-center">
            <Button 
              variant="outline" 
              className="rounded-full bg-gray-200 p-1 mr-2 h-10 w-10" 
              onClick={logout}
            >
              {userData?.user?.username?.charAt(0).toUpperCase() || "U"}
            </Button>
            <span className="hidden md:inline text-sm font-medium">
              {userData?.user?.email || "loading..."}
            </span>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <div className={`flex flex-1 overflow-hidden ${sidebarOpen ? 'mobile-nav-active' : ''} ${contentOpen ? 'mobile-content-active' : ''}`}>
        {/* Email Sidebar */}
        <EmailSidebar 
          onCompose={onCompose} 
          className={isMobile ? "email-sidebar w-64 bg-white border-r border-gray-200 flex-shrink-0 md:block" : "w-64 bg-white border-r border-gray-200 flex-shrink-0"} 
        />
        
        {/* Content */}
        {children}
      </div>
      
      {/* Floating Compose Button (Mobile) */}
      {isMobile && (
        <div className="md:hidden fixed bottom-4 right-4">
          <Button 
            className="h-14 w-14 rounded-full bg-purple-600 text-white shadow-lg flex items-center justify-center"
            onClick={onCompose}
          >
            <PenSquare className="h-6 w-6" />
          </Button>
        </div>
      )}

      {/* Compose Modal */}
      <ComposeModal isOpen={composeOpen} onClose={() => setComposeOpen(false)} />
    </div>
  );
}
