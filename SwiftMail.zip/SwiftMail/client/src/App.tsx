import { Switch, Route, useLocation, Link } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Register from "@/pages/auth/register";
import Login from "@/pages/auth/login";
import Inbox from "@/pages/dashboard/inbox";
import ViewEmail from "@/pages/dashboard/view-email";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

// Auth provider to check if user is logged in
function AuthGuard({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [location, navigate] = useLocation();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch("/api/auth/me", {
          credentials: "include"
        });
        
        if (!res.ok) {
          navigate("/login");
        }
      } catch (error) {
        toast({
          title: "Authentication Error",
          description: "Failed to verify your session. Please login again.",
          variant: "destructive"
        });
        navigate("/login");
      }
    };
    
    checkAuth();
  }, [navigate, toast]);

  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => {
        return <AuthGuard><Inbox /></AuthGuard>;
      }} />
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      <Route path="/inbox" component={() => {
        return <AuthGuard><Inbox /></AuthGuard>;
      }} />
      <Route path="/sent" component={() => {
        return <AuthGuard><Inbox folder="sent" /></AuthGuard>;
      }} />
      <Route path="/starred" component={() => {
        return <AuthGuard><Inbox folder="starred" /></AuthGuard>;
      }} />
      <Route path="/trash" component={() => {
        return <AuthGuard><Inbox folder="trash" /></AuthGuard>;
      }} />
      <Route path="/email/:id" component={({ params }) => {
        return <AuthGuard><ViewEmail id={parseInt(params.id)} /></AuthGuard>;
      }} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
