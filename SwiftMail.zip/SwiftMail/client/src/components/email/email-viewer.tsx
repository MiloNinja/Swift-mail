import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Email, User } from "@shared/schema";
import { format } from "date-fns";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft,
  Star,
  Trash,
  Reply,
  Mail,
  Paperclip,
  Smile,
  Bold,
  Italic,
  List,
  Send
} from "lucide-react";
import { Link } from "wouter";

interface EmailViewerProps {
  email: Email;
  sender?: User;
  currentUser?: User;
}

export default function EmailViewer({ email, sender, currentUser }: EmailViewerProps) {
  const [replyContent, setReplyContent] = useState("");
  const [showReply, setShowReply] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Star email mutation
  const starEmailMutation = useMutation({
    mutationFn: async (starred: boolean) => {
      const response = await apiRequest('PATCH', `/api/emails/${email.id}/star`, { starred });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/emails/folder/${email.folder}`] });
      toast({
        title: email.starred ? "Email unstarred" : "Email starred",
        description: "Email updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Action failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete email mutation
  const deleteEmailMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('DELETE', `/api/emails/${email.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/emails/folder/${email.folder}`] });
      toast({
        title: "Email deleted",
        description: "Email moved to trash.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Send reply mutation
  const sendReplyMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/emails', {
        toEmail: sender?.email,
        subject: `Re: ${email.subject}`,
        body: replyContent
      });
      return response.json();
    },
    onSuccess: () => {
      setReplyContent("");
      setShowReply(false);
      toast({
        title: "Reply sent",
        description: "Your reply has been sent successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Send failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleStar = () => {
    starEmailMutation.mutate(!email.starred);
  };

  const handleDelete = () => {
    deleteEmailMutation.mutate();
  };

  const handleReply = () => {
    setShowReply(true);
  };

  const sendReply = () => {
    if (replyContent.trim()) {
      sendReplyMutation.mutate();
    } else {
      toast({
        title: "Cannot send empty reply",
        description: "Please enter a message before sending.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Email header */}
      <div className="border-b border-gray-200 bg-white sticky top-0 z-10">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex space-x-2">
            <Link href={`/${email.folder}`}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5 text-gray-500" />
              </Button>
            </Link>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleStar}
            >
              <Star 
                className={`h-5 w-5 ${email.starred ? 'text-yellow-400 fill-yellow-400' : 'text-gray-500'}`} 
              />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleDelete}
            >
              <Trash className="h-5 w-5 text-gray-500" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleReply}
            >
              <Reply className="h-5 w-5 text-gray-500" />
            </Button>
          </div>
          <div>
            <span className="text-xs text-gray-500">
              {email.createdAt && format(new Date(email.createdAt), "MMM d, yyyy, h:mm a")}
            </span>
          </div>
        </div>
      </div>
      
      {/* Email content */}
      <div className="flex-1 p-6 overflow-auto">
        <h1 className="text-2xl font-medium text-gray-900 mb-4">{email.subject}</h1>
        
        <div className="flex items-center mb-6">
          <Avatar className="h-10 w-10 bg-purple-600 text-white">
            <AvatarFallback>
              {sender ? (sender.firstName?.charAt(0) || sender.username?.charAt(0) || "U") : "U"}
            </AvatarFallback>
          </Avatar>
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-900">
              {sender ? `${sender.firstName || ''} ${sender.lastName || ''}`.trim() || sender.username : "Unknown"}
            </p>
            <p className="text-xs text-gray-500">{sender?.email || "unknown@swift.com"}</p>
            {email.externalRecipient && (
              <p className="text-xs text-green-600 mt-1">
                <Mail className="h-3 w-3 inline mr-1" /> 
                Sent to external: {email.externalRecipient}
              </p>
            )}
          </div>
        </div>
        
        <div className="prose max-w-none text-gray-900">
          {email.body.split('\n').map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
        
        {/* Reply area */}
        {showReply && (
          <div className="mt-8 border-t border-gray-200 pt-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="mb-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700">Reply</span>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => setShowReply(false)}>
                      <ArrowLeft className="h-5 w-5 text-gray-500" />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="min-h-[100px] border border-gray-300 rounded-md px-3 py-2 shadow-sm focus-within:ring-1 focus-within:ring-purple-600 focus-within:border-purple-600">
                <Textarea 
                  rows={3} 
                  className="block w-full border-0 p-0 text-gray-900 placeholder-gray-500 focus:ring-0 sm:text-sm bg-transparent" 
                  placeholder="Type your reply here..."
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                />
              </div>
              <div className="mt-3 flex justify-between items-center">
                <div className="flex space-x-2">
                  <Button variant="ghost" size="icon">
                    <Paperclip className="h-5 w-5 text-gray-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Smile className="h-5 w-5 text-gray-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Bold className="h-5 w-5 text-gray-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Italic className="h-5 w-5 text-gray-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <List className="h-5 w-5 text-gray-500" />
                  </Button>
                </div>
                <Button 
                  className="bg-purple-600 hover:bg-purple-700"
                  onClick={sendReply}
                  disabled={sendReplyMutation.isPending}
                >
                  {sendReplyMutation.isPending ? "Sending..." : "Send"}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
