import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Paperclip, 
  Smile, 
  AlignLeft, 
  X,
  Send 
} from "lucide-react";
import { User } from "@shared/schema";
import { z } from "zod";

interface ComposeModalProps {
  isOpen: boolean;
  onClose: () => void;
  replyTo?: string;
  subject?: string;
}

// Email validation schema
const emailSchema = z.string().email("Invalid email format");

export default function ComposeModal({ 
  isOpen, 
  onClose, 
  replyTo = "", 
  subject = ""
}: ComposeModalProps) {
  const [to, setTo] = useState(replyTo);
  const [emailSubject, setEmailSubject] = useState(subject);
  const [body, setBody] = useState("");
  const [emailError, setEmailError] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (isOpen) {
      setTo(replyTo);
      setEmailSubject(subject ? (subject.startsWith("Re:") ? subject : `Re: ${subject}`) : "");
    }
  }, [isOpen, replyTo, subject]);

  // User search for autocomplete
  const { data: searchResults } = useQuery<{ users: Partial<User>[] }>({
    queryKey: ["/api/users/search", to],
    enabled: to.length > 1,
  });

  // Send email mutation
  const sendEmailMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/emails', {
        toEmail: to,
        subject: emailSubject,
        body
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Email sent",
        description: "Your email has been sent successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/emails/folder/sent"] });
      resetForm();
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Send failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setTo("");
    setEmailSubject("");
    setBody("");
  };

  // Helper to validate email
  const validateEmail = (email: string): boolean => {
    try {
      // Allow @swift.com emails without validation
      if (email.endsWith('@swift.com')) {
        return true;
      }
      
      // Validate external emails
      emailSchema.parse(email);
      setEmailError(null);
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        setEmailError(error.errors[0].message);
        return false;
      }
      setEmailError("Invalid email address");
      return false;
    }
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setEmailError(null);
    
    if (!to) {
      toast({
        title: "Missing recipient",
        description: "Please specify a recipient.",
        variant: "destructive",
      });
      return;
    }
    
    // Validate email format
    if (!validateEmail(to)) {
      toast({
        title: "Invalid email",
        description: emailError || "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }
    
    if (!emailSubject) {
      toast({
        title: "Missing subject",
        description: "Please provide a subject for your email.",
        variant: "destructive",
      });
      return;
    }
    
    if (!body.trim()) {
      toast({
        title: "Empty message",
        description: "Please write a message before sending.",
        variant: "destructive",
      });
      return;
    }
    
    sendEmailMutation.mutate();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] flex flex-col">
        <DialogHeader className="pb-2 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <DialogTitle>New Message</DialogTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5 text-gray-500" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="flex-1 overflow-auto py-4 space-y-4">
          <div>
            <Input
              type="text"
              placeholder="To (user@swift.com or any external email)"
              value={to}
              onChange={(e) => {
                setTo(e.target.value);
                if (e.target.value) validateEmail(e.target.value);
              }}
              className={`${
                emailError 
                  ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                  : 'border-gray-300 focus:border-purple-500 focus:ring-purple-500'
              }`}
            />
            {emailError && (
              <p className="text-sm text-red-500 mt-1">{emailError}</p>
            )}
          </div>
          
          <div>
            <Input
              type="text"
              placeholder="Subject"
              value={emailSubject}
              onChange={(e) => setEmailSubject(e.target.value)}
              className="border-gray-300 focus:border-purple-500 focus:ring-purple-500"
            />
          </div>
          
          <div className="flex-1">
            <Textarea
              placeholder="Write your message here..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="min-h-[200px] border-gray-300 focus:border-purple-500 focus:ring-purple-500"
              rows={12}
            />
          </div>
          
          <div className="flex justify-between items-center pt-2">
            <div className="flex space-x-2">
              <Button type="button" variant="ghost" size="icon">
                <Paperclip className="h-5 w-5 text-gray-500" />
              </Button>
              <Button type="button" variant="ghost" size="icon">
                <Smile className="h-5 w-5 text-gray-500" />
              </Button>
              <Button type="button" variant="ghost" size="icon">
                <AlignLeft className="h-5 w-5 text-gray-500" />
              </Button>
            </div>
            <Button 
              type="submit" 
              className="bg-purple-600 hover:bg-purple-700"
              disabled={sendEmailMutation.isPending}
            >
              {sendEmailMutation.isPending ? (
                "Sending..."
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Send
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
