import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Inbox, Star, Clock, SendHorizontal, Trash, File, PenSquare,
  PlusCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface EmailSidebarProps {
  className?: string;
  onCompose: () => void;
}

export default function EmailSidebar({ className, onCompose }: EmailSidebarProps) {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  return (
    <div className={cn("email-sidebar", className)}>
      <div className="p-4">
        <Button
          onClick={onCompose}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg shadow-sm flex items-center justify-center transition-colors duration-150"
        >
          <PenSquare className="h-5 w-5 mr-2" />
          <span>Compose</span>
        </Button>
      </div>
      
      <nav className="mt-2">
        <div className="px-2 space-y-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/inbox">
                  <a
                    className={cn(
                      "flex items-center px-2 py-2 text-sm font-medium rounded-md",
                      isActive("/inbox") || isActive("/")
                        ? "bg-purple-50 text-purple-600"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    )}
                  >
                    <Inbox className="h-5 w-5 mr-3" />
                    Inbox
                  </a>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>View your inbox</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/starred">
                  <a
                    className={cn(
                      "flex items-center px-2 py-2 text-sm font-medium rounded-md",
                      isActive("/starred")
                        ? "bg-purple-50 text-purple-600"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    )}
                  >
                    <Star className="h-5 w-5 mr-3 text-gray-500" />
                    Starred
                  </a>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>View starred emails</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <a
                  className="flex items-center px-2 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900"
                >
                  <Clock className="h-5 w-5 mr-3 text-gray-500" />
                  Snoozed
                </a>
              </TooltipTrigger>
              <TooltipContent>
                <p>Coming soon</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/sent">
                  <a
                    className={cn(
                      "flex items-center px-2 py-2 text-sm font-medium rounded-md",
                      isActive("/sent")
                        ? "bg-purple-50 text-purple-600"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    )}
                  >
                    <SendHorizontal className="h-5 w-5 mr-3 text-gray-500" />
                    Sent
                  </a>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>View sent emails</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Link href="/trash">
                  <a
                    className={cn(
                      "flex items-center px-2 py-2 text-sm font-medium rounded-md",
                      isActive("/trash")
                        ? "bg-purple-50 text-purple-600"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    )}
                  >
                    <Trash className="h-5 w-5 mr-3 text-gray-500" />
                    Trash
                  </a>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>View deleted emails</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <a
                  className="flex items-center px-2 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900"
                >
                  <File className="h-5 w-5 mr-3 text-gray-500" />
                  Drafts
                </a>
              </TooltipTrigger>
              <TooltipContent>
                <p>Coming soon</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        
        <div className="mt-8">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Labels
          </h3>
          <div className="mt-2 px-2 space-y-1">
            <a
              className="flex items-center px-2 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900"
            >
              <span className="h-3 w-3 rounded-full bg-green-500 mr-3"></span>
              Work
            </a>
            <a
              className="flex items-center px-2 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900"
            >
              <span className="h-3 w-3 rounded-full bg-blue-500 mr-3"></span>
              Personal
            </a>
            <a
              className="flex items-center px-2 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900"
            >
              <span className="h-3 w-3 rounded-full bg-yellow-500 mr-3"></span>
              Important
            </a>
            <Button variant="ghost" className="w-full justify-start text-sm font-medium text-gray-600">
              <PlusCircle className="h-4 w-4 mr-2" />
              Create new label
            </Button>
          </div>
        </div>
      </nav>
    </div>
  );
}
