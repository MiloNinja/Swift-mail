import { useCallback } from "react";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { Email, User } from "@shared/schema";
import { Mail } from "lucide-react";

interface EmailListItemProps {
  email: Email;
  sender?: User;
  isActive?: boolean;
  onSelect?: (selected: boolean) => void;
}

export default function EmailListItem({ 
  email, 
  sender, 
  isActive = false,
  onSelect
}: EmailListItemProps) {
  const handleCheckboxChange = useCallback((checked: boolean) => {
    if (onSelect) {
      onSelect(checked);
    }
  }, [onSelect]);

  return (
    <Link href={`/email/${email.id}`}>
      <a className={cn(
        "email-list-item p-4 cursor-pointer transition-colors border-l-0 hover:bg-purple-50/30",
        isActive && "border-l-3 border-purple-600 bg-purple-50/50"
      )}>
        <div className="flex items-start">
          <div className="flex-shrink-0 pt-1">
            <Checkbox
              className="h-4 w-4 text-purple-600 focus:ring-purple-600 border-gray-300 rounded"
              checked={false}
              onCheckedChange={handleCheckboxChange}
              onClick={(e) => e.stopPropagation()}
            />
          </div>
          <div className="ml-3 flex-1">
            <div className="flex items-center justify-between">
              <p className={cn(
                "text-sm font-medium",
                email.read ? "text-gray-600" : "text-gray-900"
              )}>
                {sender?.firstName} {sender?.lastName || sender?.username || "Unknown"}
              </p>
              <p className="text-xs text-gray-500">
                {email.createdAt 
                  ? formatDistanceToNow(new Date(email.createdAt), { addSuffix: true }) 
                  : "Recently"}
              </p>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <p className={cn(
                  "text-sm",
                  email.read ? "font-normal text-gray-600" : "font-medium text-gray-900"
                )}>
                  {email.subject}
                </p>
                {email.externalRecipient && (
                  <Mail className="h-3 w-3 text-green-500" />
                )}
              </div>
              <p className="text-sm text-gray-500 line-clamp-1">
                {email.externalRecipient ? 
                  `To: ${email.externalRecipient} - ${email.body}` : 
                  email.body
                }
              </p>
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
}
